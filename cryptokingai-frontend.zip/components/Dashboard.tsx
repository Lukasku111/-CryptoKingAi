'use client';
import React, { useState, useEffect } from "react";
import { Line } from "react-chartjs-2";

export default function Dashboard() {
  const [wallet, setWallet] = useState("");
  const [aiInsight, setAIInsight] = useState("");
  const [tokenInput, setTokenInput] = useState("");
  const [scoredToken, setScoredToken] = useState(null);

  const dummyData = {
    labels: ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"],
    datasets: [{ label: "Portfolio Value ($)", data: [800, 920, 1100, 1450, 1700, 1950, 2300], borderColor: "#10b981" }],
  };

  const getAIInsight = async () => {
    const res = await fetch("/api/ai-insight", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ prompt: wallet }),
    });
    const data = await res.json();
    setAIInsight(data.insight);
  };

  const getTokenScore = async () => {
    const res = await fetch("/api/score-token", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ token: tokenInput }),
    });
    const data = await res.json();
    setScoredToken(data);
  };

  return (
    <main style={{ padding: 20, fontFamily: 'sans-serif' }}>
      <h1>CryptoKingAI 🧠</h1>
      <input placeholder="Wallet address" value={wallet} onChange={(e) => setWallet(e.target.value)} />
      <button onClick={getAIInsight}>Analyze Wallet</button>
      <pre>{aiInsight}</pre>

      <input placeholder="Token CA" value={tokenInput} onChange={(e) => setTokenInput(e.target.value)} />
      <button onClick={getTokenScore}>Score Token</button>
      {scoredToken && <pre>{JSON.stringify(scoredToken, null, 2)}</pre>}

      <Line data={dummyData} />
    </main>
  );
}